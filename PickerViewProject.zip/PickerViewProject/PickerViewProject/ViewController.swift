//
//  ViewController.swift
//  PickerViewProject
//
//  Created by student on 2018/5/7.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    let city = ["台北","台中","高雄","花蓮","台東"]
    
    //要顯示幾個類別的資料
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    //要顯示幾個選項
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return city.count
    }
    
    //每個選項的標題
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "Apple"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

