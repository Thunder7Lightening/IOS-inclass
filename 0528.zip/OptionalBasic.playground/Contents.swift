//var myNumber:Int? = 7
//
//// 第一種方法（不好）
//myNumber! + 10
//
//// 第二種方法
//if myNumber != nil{
//    myNumber! + 10
//}
//
//// 第三種方法（optional binding）
//if let okNumber = myNumber{
//    okNumber + 10
//}
//
//
//
//
//var loadedScore:Int? = 1000
//
//var highScore:Int = loadedScore != nil ? loadedScore! : 0
//
//highScore = loadedScore ?? 0 // loadedScore not nil return itself, else return 0
//
//
//
//
//
//func someFunction(number:Int?, name:String?){
////    if let okNumber = number{
////        print(okNumber)
////    }
//
//    guard let okValue = number else { return }
//}




// closure
// 1.刪除 func 跟函式名稱
// 2.把參數跟回傳值放到大括號中
// 3.加入關鍵詞 in

func sayHello(){
    print("Hello Everybody")
}

let helloClosure:()->() = {
    print("Hello Everybody")
}

helloClosure()



func eat(foodName:String){
    print("I wanna eat \(foodName)")
}

let eatClosure2:(String)->()
let eatClosure:(String)->Void = {
    (foodName:String) in
    print("I wanna eat \(foodName)")
}

eatClosure("Hamburger")



func hi(name:String) -> String{
    return "hi" + name
}

let hiClosure:(String)->String = {
    (name:String) -> String in
    return "hi" + name
}

hiClosure("Thomas")



func add(num1:Int, num2:Int) -> Int{
    return (num1 + num2)
}

let addClosure:(Int, Int)->Int = {
    (num1:Int, num2:Int) -> Int in
    return (num1 + num2)
}

addClosure(3,5)



func someFunction(){
    print("Hello World")
}

var x = someFunction
x()



// Closure 的簡寫
// 1.如果已知參數的型別與回傳值的型別 closure中可以省略不用標示
// 2.如果closure有回傳值的話，而且程式碼又只有一行，可以省略return
// 3.第一個參數可以用$0代表，第二個參數可以用$1代表
// 4.如果closure是最後一個參數的話，可以把clousre放到小括號的外面
// 5.如果closure是唯一的參數的話，可以省略小括號

//let addClosure:(Int, Int)->Int = { $0 + $1 }

var fruitArray = ["apple", "banana", "mango", "watermelon"]
fruitArray.append("kiwi")

// array 的 map 方法：把陣列的每個成員都拿出來做一些事情
fruitArray.map{ print($0) }

// array 的 filter 方法：過濾成員
fruitArray.filter{ return $0.count > 5 }



func giveMeCounter()->()->(Int){
    var counterNumber = 0
    return { ()->Int
        in
        counterNumber += 1
        return counterNumber
    }
}

let counter = giveMeCounter()
counter()
counter()
counter()










