//
//  GreenViewController2.swift
//  NavigationBasic
//
//  Created by student on 2018/5/21.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class GreenViewController2:UIViewController{
    
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myTextField: UITextField!
    
    var infoFromRed:String?
    
    @IBAction func back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // 拿到使用者輸入的文字
        let inputText = myTextField.text
        // 刪掉文字輸入框的文字
        myTextField.text = ""
        // 找到下一個 view controller
        if let bvc = segue.destination as? BlueViewController{
            // 傳值到下一個 view controller
            bvc.infoFromGreen = inputText
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myLabel.text = infoFromRed
    }
}
