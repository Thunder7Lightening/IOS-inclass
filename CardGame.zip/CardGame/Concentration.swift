//
//  Concentration.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

class Concentration {
    //var cards = Array<Card>
    //var cards = Array<Card>()
    var cards = [Card]()
    
    init(numberOfPairsCards: Int)
    {
        for _ in 1...numberOfPairsCards {
            let card = Card()
            //cards.append(card)
            //cards.append(card)
            cards += [card, card]
        }
    }
    
    func chooseCard(at index: Int)
    {
         cards[index].isFaceUp = !cards[index].isFaceUp
    }
}
