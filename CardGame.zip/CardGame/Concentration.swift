//
//  Concentration.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

//extension Collection{
//    var oneAndOnly: Element?{
//        return count == 1 ? first : nil
//    }
//}

struct Concentration {
    //var cards = Array<Card>
    //var cards = Array<Card>()
    var cards = [Card]()
    
    init(numberOfPairsCards: Int)
    {
        for _ in 1...numberOfPairsCards {
            let card = Card()
            //cards.append(card)
            //cards.append(card)
            cards += [card, card]
        }
    }
    
    // 儲存場面上只有一張face up的卡片的index
    var indexOfOneAndOnlyOneFaceUpCard:Int?{
        get{
//            let faceUpCardIndices = cards.indices.filter{cards[$0].isFaceUp} // $0 is index
//            return faceUpCardIndices.count == 1 ? faceUpCardIndices.first : nil // if count == 1 return index
//            return cards.indices.filter{cards[$0].isFaceUp}.oneAndOnly // another way instead of the upper 2 instr.
            
            var foundIndex: Int?
            for index in cards.indices{
                if cards[index].isFaceUp{
                    if foundIndex == nil{
                        foundIndex = index
                    }
                    else
                    {
                        return nil
                    }
                }
            }
            return foundIndex
        }
        set{
            for index in cards.indices{
                cards[index].isFaceUp = (index == newValue)
            }
        }
    }
    
    mutating func chooseCard(at index: Int)
    {
        if !cards[index].isMathched
        {
            if let matchingIndex = indexOfOneAndOnlyOneFaceUpCard, matchingIndex != index
            {
                if cards[matchingIndex]/*.identifier*/ == cards[index]/*.identifier*/
                {
                    cards[matchingIndex].isMathched = true
                    cards[index].isMathched = true
                }
                cards[index].isFaceUp = true
                //indexOfOneAndOnlyOneFaceUpCard = nil
            }
            else // if indexOfOneAndOnlyOneFaceUpCard is nil
            {
//                for flipDownIndex in cards.indices{
//                    cards[flipDownIndex].isFaceUp = false
//                }
//                cards[index].isFaceUp = true
                indexOfOneAndOnlyOneFaceUpCard = index
            }
        }
    }
}
	
