//
//  Concentration.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

class Concentration {
    //var cards = Array<Card>()
    var cards = [Card]()
    
    init(numberOfPairsCards: Int) {
        for identifier in 1...numberOfPairsCards {
            let card = Card(identifier: identifier)
            //cards.append(card)
            //cards.append(card)
            cards += [card, card]
        }
    }
}
