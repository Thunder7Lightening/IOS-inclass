//
//  ViewController.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import UIKit

extension Int{
    var arc4random: Int{
        if self > 0{
            return Int(arc4random_uniform(UInt32(self)))
        }else if self < 0{
            return -Int(arc4random_uniform(UInt32(abs(self))))
        }else{
            return 0
        }
    }
}

class ViewController: UIViewController {
    
    lazy var game = Concentration(numberOfPairsCards: 3)//numberOfPairsOfCardsOnTable)
    
    var numberOfPairsOfCardsOnTable:Int{
        return (cardButtons.count + 1) / 2
    }
    
    var flipCount = 0{
        didSet{
            let attributes: [NSAttributedString: Any] = [
                .strokeWidth: 5.0
                .strokeColor: UIColor.orange
            ]
            let attributedString = NSAttributedString(string: "Flip: \(flipCount)", attributes: attributes)
            flipLabel.attributedText = attributedString
//            flipLabel.text = "Flip: \(flipCount)"
        }
    }
    
    @IBOutlet weak var flipLabel: UILabel!
    @IBOutlet var cardButtons: [UIButton]!
    
//    var emojiChoices: Array<String> = ["🏈","🏀","🏌","🏇","🎫","🎻","😚","🍧","🍼"]
    var emojiChoices: String = "🏈🏀🏌🏇🎫🎻😚🍧🍼"
    var emojiDict = [Card: String]()//[Int: String]()
    
    @IBAction func touchCard(_ sender: UIButton) {
        flipCount += 1
        if let cardNumber = cardButtons.index(of: sender) // it's a constant since we will not change it again
        {
            //flipCard(withEmoji: emojiChoices[cardNumber], on: sender)
            
            game.chooseCard(at: cardNumber)
            updateViewFromModel()
        }
        else
        {
            print("error")
        }
        
    }
    
//    func getEmoji(for card:Card) ->String
//    {
//        if emojiDict[card/*.identifier*/] == nil, emojiChoices.count > 0
//        {
//            let randomIndex = emojiChoices.count.arc4random //Int(arc4random_uniform(UInt32(emojiChoices.count)))
//            emojiDict[card/*.identifier*/] = emojiChoices.remove(at: randomIndex)
//        }
//        return emojiDict[card/*.identifier*/] ?? "x" // if emojiDict[] is nil, then return "x"
//    }
    
    func getEmoji(for card:Card) ->String
    {
        if emojiDict[card/*.identifier*/] == nil, emojiChoices.count > 0
        {
//            let randomIndex = emojiChoices.count.arc4random //Int(arc4random_uniform(UInt32(emojiChoices.count)))
            let randomStringIndex = emojiChoices.index(emojiChoices.startIndex, offsetBy: arc4random_uniform(UInt32(emojiChoices.count))
            emojiDict[card/*.identifier*/] = emojiChoices.remove(at: randomStringIndex)
        }
        return emojiDict[card/*.identifier*/] ?? "x" // if emojiDict[] is nil, then return "x"
    }
    
    func updateViewFromModel()
    {
        for index in cardButtons.indices
        {
            let button = cardButtons[index]
            let card = game.cards[index]
            
            if card.isFaceUp
            {
                button.setTitle(getEmoji(for: card), for: UIControlState.normal)
                button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            }
            else
            {
                button.setTitle("", for: UIControlState.normal)
                button.backgroundColor = card.isMathched ? #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1) : #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
            }
        }
    }

    func flipCard(withEmoji emoji:String, on button:UIButton)
    {
        if button.currentTitle == emoji
        {
            button.setTitle("", for: UIControlState.normal)
            button.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        }
        else
        {
            button.setTitle(emoji, for: UIControlState.normal)
            button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
    }

}

