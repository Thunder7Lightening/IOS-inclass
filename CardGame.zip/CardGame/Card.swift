//
//  Card.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

struct Card : Hashable{ // struct is call by value // class is call by reference
    var hashValue: Int{
        return identifier
    }
    
    static func ==(lhs: Card, rhs: Card) -> Bool{
        return lhs.identifier == rhs.identifier
    }
    
    var isFaceUp = false
    var isMathched = false
    private var identifier:Int
    
    init() {
        self.identifier = Card.getUniqueIdentifier()
    }
    
    static var identifierFactory = 0
    
    static func getUniqueIdentifier() ->Int
    {
        /*Card.*/identifierFactory += 1
        return identifierFactory
    }
}

//底下寄生

//enum FryOrderSize{
//    case large
//    case medium
//    case small
//}
//
//enum FastFoodMenuItem{
//    case hamburger(numberOfPatties: Int)
//    case fries(size: FryOrderSize)
//}
//
//let menuItem = FastFoodMenuItem.hamburger(numberOfPatties: 2)
//switch menuItem{
//case .hamburder(let pattyCount):
//    print("a burger with \(pattyCount) patties!")
//case .fries: print("fries")
//default:
//    print("other")
//    print("foods")
//}
//
//let otherItem = FastFoodMenuItem.fries(size: .large)





