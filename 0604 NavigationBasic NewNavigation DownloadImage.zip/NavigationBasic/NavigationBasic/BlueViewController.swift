//
//  BlueViewController.swift
//  NavigationBasic
//
//  Created by student on 2018/5/21.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

protocol BlueViewControllerDelegate{
    func setColor(colorType:String)
}

class BlueViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var infoFromGreen:String?

    @IBOutlet weak var myLabel: UILabel!
    
    @IBOutlet weak var myPickerView: UIPickerView!
    let colors = ["red", "green", "blue"]
    
    var delegate:BlueViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myPickerView.dataSource = self
        myPickerView.delegate = self
        
        myLabel.text = infoFromGreen
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return colors.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return colors[row]
    }

    @IBAction func back(_ sender: UIButton) {
        // 讓藍色的畫面降下
        dismiss(animated: true, completion: nil)
        // 把藍色畫面的選項，傳回上一個畫面
        // 得到選取的 index
        let selectedIndex = myPickerView.selectedRow(inComponent: 0)
        // 得到選取的顏色
        let selectedColor = colors[selectedIndex]
        
        delegate?.setColor(colorType: selectedColor)
    }
    
}
