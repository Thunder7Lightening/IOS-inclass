//
//  GreenViewController2.swift
//  NavigationBasic
//
//  Created by student on 2018/5/21.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class GreenViewController2:UIViewController, BlueViewControllerDelegate{
    
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myTextField: UITextField!
    
    var infoFromRed:String?
    
    func setColor(colorType: String) {
        if colorType == "red"{
            view.backgroundColor = .red
        }else if colorType == "green"{
            view.backgroundColor = .green
        }else{
            view.backgroundColor = .blue
        }
    }
    
    @IBAction func back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // 拿到使用者輸入的文字
        let inputText = myTextField.text
        // 刪掉文字輸入框的文字
        myTextField.text = ""
        // 找到下一個 view controller
        if segue.identifier == "gotoview3"{
            if let bvc = segue.destination as? BlueViewController{
                // 傳值到下一個 view controller
                bvc.infoFromGreen = inputText
                bvc.delegate = self
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myLabel.text = infoFromRed
    }
}
