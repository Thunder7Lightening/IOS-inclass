//
//  ViewController.swift
//  NewNavigation
//
//  Created by student on 2018/6/4.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func next(_ sender: UIButton) {
        // 找出 main.storyboard
        let main = UIStoryboard(name: "Main", bundle: nil)
        // 產生 green view controller
        let gvc = main.instantiateViewController(withIdentifier: "green")
        // 包著自己的 navigation controller，推出 push green view controller
        // 從右到左
//        self.navigationController?.pushViewController(gvc, animated: true)
        // 從下到上
        present(gvc, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

