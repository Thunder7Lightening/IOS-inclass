//
//  ViewController.swift
//  DownloadImage
//
//  Created by student on 2018/6/4.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 兩個工作
        let task1 = {
            for i in 1...5{
                print("Task1:\(i)")
            }
        }
        
        let task2 = {
            for i in 1...5{
                print("Task2:\(i)")
            }
        }
        
        // 在 Main Queue 執行(一定要設async，否則畫面當掉)
        // 跟畫面相關
        // 只能做 async 工作
        // 不會同時做兩個工作，先做一件，再做另外一件工作
//        DispatchQueue.main.async(execute: task1)
//        DispatchQueue.main.async(execute: task2)
        
        // global queue 可以同步或非同步的工作
        // 非同步的話，可以同時做好幾份工作
        DispatchQueue.global().async(execute: task1)
        DispatchQueue.global().async(execute: task2)
        
        downloadImage()
    }
    
    func downloadImage(){
        // 下載圖檔 : 圖片的網址 > url > 下載
        let address = "https://cdn3.macworld.co.uk/cmsdata/features/3523633/swift_1200home_thumb800.jpg"
        if let url = URL(string: address){
            DispatchQueue.global().async {
                // 到背景下載
                do{
                    // 下載圖片
                    let data = try Data(contentsOf: url)
                    DispatchQueue.main.async {
                        // 到 Main Queue 秀出圖片
                        self.myImageView.image = UIImage(data: data)
                    }
                }catch{
                    // 跳出 alert
                    print(error.localizedDescription)
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

