//: Playground - noun: a place where people can play

import UIKit

//Q(1)
protocol Area{
    mutating func getArea(r:Double) -> Double
}

struct Circle:Area{
    var radius = 0.0
    
    mutating func getArea(r:Double) -> Double{
        radius = r
        return radius*radius*3.14159
    }
}

var circleObject = Circle()
print("Circle Area = \(circleObject.getArea(r: 10))")



//Q(2)
class CircleCircle:Area{
    var radius = 0.0
    
    func getArea(r:Double) -> Double{
        radius = r
        return radius*radius*3.14159
    }
}

var circleObject2 = CircleCircle()
print("Circle Area = \(circleObject2.getArea(r: 10))")

//-----------------------------------------------------------
//Q(3)
protocol GetArea{
    var area:Double{get}
}

class CircleObject:GetArea{
    var radius:Double
    init(radius:Double){
        self.radius = radius
    }
    var area:Double{
        // implement your code here
        return self.radius * self.radius * 3.14159
    }
}

class Rectangle:GetArea{
    var width:Double
    var height:Double
    init(width:Double, height:Double){
        self.width = width
        self.height = height
    }
    
    // implement your code here
    var area:Double{
        get{
            return self.width * self.height
        }
    }
    
}

class Whatever{
    var message: String
    init(msg:String){
        self.message = msg
    }
}

let objects:[AnyObject] = [
    CircleObject(radius: 20.0),
    Rectangle(width: 20.0, height: 10.0),
    Whatever(msg:"hello"),
    CircleObject(radius: 10.0)
]

for object in objects{
    // print the area if it is the type of GetArea
    // otherwise print the warning message
    
    //for example the print msg should be
    //Area =1256.636
    //Area =200.0
    //there is no ares for this object
    //Area =314.159
    
    // implement your code here
    if let shapeObject = object as? GetArea{
        print(shapeObject.area)
    }else{
        print("there is no ares for this object")
    }
}