//protocol 協定
protocol CoffeeGetable{
    func giveMeCoffee()
}

class SevenEleven:CoffeeGetable{ // 服從協定
    // 服從協定要實作方法
    func giveMeCoffee() {
        print("拿鐵咖啡給你")
    }
}

protocol MoneyTransferProtocol{
    func giveMoney()
}

class RichPeople:MoneyTransferProtocol{
    func giveMoney() {
        print("Give you 10000 Dollars~")
    }
}

class PoorGuy{
    var helper:MoneyTransferProtocol?
    func needMoney(){
        helper?.giveMoney()
    }
}

let aPoorGuy = PoorGuy()
let aRichPeople = RichPeople()

aPoorGuy.helper = aRichPeople
aPoorGuy.needMoney()
