//
//  ViewController.swift
//  PickerViewProject
//
//  Created by student on 2018/5/7.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class GreenViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
    }
}

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var myPickerView: UIPickerView!
    
    @IBAction func btnPressed(_ sender: UIButton) {
        let selectedZero = myPickerView.selectedRow(inComponent: 0)
        let selectedOne = myPickerView.selectedRow(inComponent: 1)
        print(numbers[selectedZero] + city[selectedOne])
    }
    
    let city = ["台北","台中","高雄","花蓮","台東"]
    let numbers = ["1","2","3","4","5","6","7","8","9","10"]
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 50
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        if component == 0{
            return 100
        }else{
            return view.frame.width - 100
        }
    }
    
//    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
//        let thisView = UIView()
//        if component == 0{
//            thisView.backgroundColor = .green
//
//            let imageView = CGRect(x: 0, y: 0, width: 100, height: 100)
//
//            imageView.image = UIImage(named: "cat\(row + 1)")
//            thisView.addSubview(imageView)
//        }else{
//            thisView.backgroundColor = .blue
//        }
//        return thisView
//    }
    
    //要顯示幾個類別的資料
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }

    //要顯示幾個選項
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return numbers.count
        }else{
            return city.count
        }
    }

    //每個選項的標題
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return numbers[row]
        }else{
            return city[row]
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myPickerView.dataSource = self
        myPickerView.delegate = self
        myPickerView.selectRow(1, inComponent: 1, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

