//
//  ViewController.swift
//  NavigationBasic
//
//  Created by student on 2018/5/21.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func next(_ sender: UIButton) {
//        performSegue(withIdentifier: "gotoview2", sender: nil)
        //找到 main storyboard
        let mainStoryboard =  UIStoryboard(name: "Main", bundle: nil)
        //找到下一個畫面
        let greenViewController =  mainStoryboard.instantiateViewController(withIdentifier: "green")
        //呈現，推出來
        present(greenViewController, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

