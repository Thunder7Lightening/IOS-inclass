//
//  GreenViewController2.swift
//  NavigationBasic
//
//  Created by student on 2018/5/21.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class GreenViewController2:UIViewController{
    
    @IBAction func back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}
