//
//  ViewController.swift
//  RandomUserProject
//
//  Created by student on 2018/6/11.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

struct AllData:Decodable{
    var results:[SingleData]?
}

struct SingleData{
    var name:Name?
    var email:String?
    var phone:String?
    var picture:Image?
}

struct Name{
    var first:String?
    var last:String?
}

struct Image{
    var medium:String?
}

class ViewController: UIViewController {

    // 產生 URLSession
    lazy var session = URLSession(configuration: .default)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        downloadInfo()
    }
    
    func downloadInfo(){
        // 用這個函式來下載資料
        // 網址 > URL > URLSession 下載
        let address = "https://randomuser.me/api/"
        // 得到 URL
        guard let url = URL(string: address) else { return }
        // 產生下載的工作
        let task = session.dataTask(with: url) { (data, response, error) in
            // 如果有錯誤的話，印出錯誤，跳出不再繼續下去
            if error != nil{
                print(error?.localizedDescription ?? "")
                return
            }
            
            // 如果真的有資料的話，印出來．．．
            if let okData = data{
                let jsonDecoder = JSONDecoder()
                do{
                    let info = try jsonDecoder.decode(AllData.self, from: okData)
                    if let firstName = info.results?[0].name?.first{
                        print(firstName)
                    }
                }catch{
                    
                }
                
                
                
//                do{
//                    let json = try JSONSerialization.jsonObject(with: okData, options: JSONSerialization.ReadingOptions.mutableContainers)
////                    print(json)
//                    self.handleJson(data: json)
//                }catch{
//                    print(error.localizedDescription)
//                }
            }
        }
        // 開始下載
        task.resume()
    }
    
    func handleJson(data:Any){
        if let allData = data as? [String:Any]{
            if let results = allData["results"] as? [[String:Any]]{
                if let email = results[0]["email"] as? String{
                    print(email)
                }
                
                // get name, then get first
                if let name = results[0]["name"] as? [String:Any]{
                    if let firstName = name["first"] as? String{
                        print(firstName)
                    }
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

