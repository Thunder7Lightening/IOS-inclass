//
//  ViewController.swift
//  DownloadImage
//
//  Created by student on 2018/6/4.
//  Copyright © 2018年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    var session: URLSession?
    
    override func viewDidLoad() {
        super.viewDidLoad()
//
//        // 兩個工作
//        let task1 = {
//            for i in 1...5{
//                print("Task1:\(i)")
//            }
//        }
//
//        let task2 = {
//            for i in 1...5{
//                print("Task2:\(i)")
//            }
//        }
//
//        // 在 Main Queue 執行(一定要設async，否則畫面當掉)
//        // 跟畫面相關
//        // 只能做 async 工作
//        // 不會同時做兩個工作，先做一件，再做另外一件工作
////        DispatchQueue.main.async(execute: task1)
////        DispatchQueue.main.async(execute: task2)
//
//        // global queue 可以同步或非同步的工作
//        // 非同步的話，可以同時做好幾份工作
//        DispatchQueue.global().async(execute: task1)
//        DispatchQueue.global().async(execute: task2)
        
//        downloadImage()
        
        // 產生 URLSession
        session = URLSession(configuration: .default)
        // 用 URLSession 去下載圖片
        //downloadWithURLSession()
        downloadWithURLSessionAgain()
    }
    
    func downloadWithURLSessionAgain(){
        // 網址
        let address = "https://cdn3.macworld.co.uk/cmsdata/features/3523633/swift_1200home_thumb800.jpg"
        // 用網址產生 URL
        guard let url = URL(string: address) else { return }
        // 用 URLSession, downloadTask 來下載圖片
        let task = session?.downloadTask(with: url, completionHandler: {
            (url, response, error) in
            guard error == nil else { return }
            guard let okURL = url else { return }
            
            do{
                let data = try Data(contentsOf: okURL)
                DispatchQueue.main.async {
                    self.myImageView.image = UIImage(data: data)
                }
            }catch{
                print("something wrong")
            }
        })
        // 真的去下載
        task?.resume()
    }
    
    func downloadWithURLSession(){
        // 網址
        let address = "https://cdn3.macworld.co.uk/cmsdata/features/3523633/swift_1200home_thumb800.jpg"
        // 用網址產生 URL
        guard let url = URL(string: address) else { return }
        
        // 產生下載的工作
        let task = session?.dataTask(with: url, completionHandler: {
            (data, response, error) in
            // 真的有錯誤，就不要繼續做下去了
            if error != nil{
                print(error?.localizedDescription ?? "")
                return
            }
            
            // 真的有資料的話，秀出圖片
            if let okData = data{
                // 在主要跟 UI 相關的佇列去更新圖片
                DispatchQueue.main.async {
                    self.myImageView.image = UIImage(data: okData)
                }
            }
            
        })
        // 真的開始下載
        task?.resume()
    }
    
    func downloadImage(){
        // 下載圖檔 : 圖片的網址 > url > 下載
        let address = "https://cdn3.macworld.co.uk/cmsdata/features/3523633/swift_1200home_thumb800.jpg"
        if let url = URL(string: address){
            DispatchQueue.global().async {
                // 到背景下載
                do{
                    // 下載圖片
                    let data = try Data(contentsOf: url)
                    DispatchQueue.main.async {
                        // 到 Main Queue 秀出圖片
                        self.myImageView.image = UIImage(data: data)
                    }
                }catch{
                    // 跳出 alert
                    print(error.localizedDescription)
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

